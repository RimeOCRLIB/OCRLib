//
//  global.cpp
//  OCRLib
//
//  Created by dharmabook on 25/05/15.
//
//

#include "global.h"
using namespace std;
using namespace aiml;

