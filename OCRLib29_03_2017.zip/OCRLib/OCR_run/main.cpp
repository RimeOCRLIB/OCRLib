//
//  main.cpp
//  OCR_run
//
//  Created by dharmabook on 09/09/15.
//
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
