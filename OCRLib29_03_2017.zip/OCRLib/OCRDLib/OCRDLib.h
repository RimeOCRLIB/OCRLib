//
//  OCRDLib.h
//  OCRDLib
//
//  Created by dharmabook on 25/10/16.
//
//

#import <Foundation/Foundation.h>

@interface OCRDLib : NSObject

@end
