//
//  OCRDLib.m
//  OCRDLib
//
//  Created by dharmabook on 25/10/16.
//
//

#import "OCRDLib.h"

@implementation OCRDLib

@end
