/*
 *  OCRLibGMap.h
 *  OCRLibGMap
 *
 *  Created by dharmabook on 25/10/16.
 *
 *
 */

#ifndef OCRLibGMap_
#define OCRLibGMap_

/* The classes below are exported */
#pragma GCC visibility push(default)

class OCRLibGMap
{
	public:
		void HelloWorld(const char *);
};

#pragma GCC visibility pop
#endif
