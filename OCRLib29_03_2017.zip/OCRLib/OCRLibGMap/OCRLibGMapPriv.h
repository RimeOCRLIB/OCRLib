/*
 *  OCRLibGMapPriv.h
 *  OCRLibGMap
 *
 *  Created by dharmabook on 25/10/16.
 *
 *
 */

/* The classes below are not exported */
#pragma GCC visibility push(hidden)

class OCRLibGMapPriv
{
	public:
		void HelloWorldPriv(const char *);
};

#pragma GCC visibility pop
