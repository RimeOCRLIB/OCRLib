#include "GBitsetMatrix.h"
#include "GBitsetMatrix.h"

void GBitsetMatrix::letterCorrelationBase(vector<OCRMatch>&matchLine,
                                       GFont *aliKali,
                                       int lineIndex,
                                       int y0,
                                       int y1,
                                       int scaleMode,
                                       int OCRMode,
                                       int print){
    
    //aliKali - указатель на массив букв (база букв).
    //aliKali[0].alLetterCount - количество букв в базе
    //BitMask32 *mask=&aliKali[0][1].mask32[0];  -- указатель на первую маску во второй букве базы
    //aliKali[0][1].mask32Count - количество масок во второй букве базы
    //stringArray - массив строк как в CBitset
    //stringNum - номер строки в массиве
    
    // resize(ncnr) векторных массивов сделан в Bitset_base.h
#define  c_out_ cout
#define  c_out1_ inputData.c_out
    
#ifdef REPORT
    DR("inputData.name"<<inputData.data["name"]<<" border="<<border<<END)
    int mCMax=0; string name;
#endif
    
    //GBitMask32 *mask;//=&aliKali[0][2].mask32[0];  //-- указатель на первую маску во второй букве базы
    //DM("/1/____aliKali[0].Wylie"<<aliKali[0].Wylie.c_str());
    //printMask(mask,c_out);
    //TIME_START
    
    //print=1;
    
    int mC,mC0,dX,dY,mY,mX;
    int maxX,maxY,maxSumX,maxSumY,count;
    int letterY0, maskY0, maskY1,limitY, xCenter;
    GLetter *glyph;
    
/*
    // константы для алгоритма подсчета единиц в 128 или в 64р словах
    static const unsigned int constF[12]={              // 12  16
        0x33333333, 0x33333333, 0x33333333, 0x33333333,
        0x55555555, 0x55555555, 0x55555555, 0x55555555,
        0x0f0f0f0f, 0x0f0f0f0f, 0x0f0f0f0f, 0x0f0f0f0f  // ,
        //	0x00000000, 0x00000000, 0x00000000, 0x00000000  // TEST
    };
*/
    
    // переход в режим Assembler, загрузка констант
#if defined ASM_OS64_SSE3 || defined ASM_OS32_SSE2
    
    __asm{     //  movups (без требования выравнивания)
        /// Для выполнения в регистрах MMX
#ifdef MMX	
        // загрузка констант в регистр 64p ММХ ( считаем в байтах - int*4)
        movq            mm5, qword ptr constF+16;   // 55 Пересылка данных (64 бит)
        movq            mm6, qword ptr constF;      // 33 из/в регистр ММХ  MOVDQU-128
        movq            mm7, qword ptr constF+32;   // 0f
#endif
        // загрузка констант в регистр 128p SSE
        //  movups без требования выравнивания  ( MOVAPS должны быть выровнены )
#ifdef WIN32
        //Vic movups          xmm5, dqword ptr constF+16;  // 55  Пересылка данных (128 бит)
        //Vic movups          xmm6, dqword ptr constF;     // 33  + MOVDQU
        //Vic movups          xmm7, dqword ptr constF+32;  // 0f
        //	movups          xmm2, dqword ptr constF+48;  // TEST
#else
        movups          xmm5, [constF+16];  // 55  Пересылка данных (128 бит)
        movups          xmm6, [constF+0];     // 33  + MOVDQU
        movups          xmm7, [constF+32];  // 0f
        //movups          xmm2, dqword ptr constF+48;  // TEST
#endif
        
    }; // __asm
    
#endif   
	
    //Инструкция movq выполняется за шесть тактов, тогда как для pshufw требуется только два
    /**/
    
    //clock_t  tm_start, tm_end ,tm_0=0, tm_1=0; double time; // tm_start=clock();
    //static clock_t tm0=0, tm1=0;
    int deltaSearch;
    if(OCRMode==1)deltaSearch=8;
    if(OCRMode==2)deltaSearch=8;
    
    
    for(int in=0; in<aliKali->letterCount();in++){  //DR(" in="<<in<<" name"<<aliKali[0][in]->name.c_str())
        glyph=aliKali->getLetter(in);
        //cout_<<" in="<<in<<" name"<<glyph->name;
        //if(in!=13138)continue; print=1;
        //if(glyph->name!="སྒྲུ"){glyph->destroy();continue;} print=1;
        
        if(glyph->mask32Count()==0){glyph->destroy();continue;}
        
        if(inputData.data["ocrLn"]=="ocrTibetan"){
            if(!RE2::PartialMatch(glyph->name,"[\\p{Tibetan}\\d\\]\\[«»［］｛｝—⊕\\|\\(\\)\\-]+")
               &&!RE2::PartialMatch(glyph->name,"\\[[\\d]+")){glyph->destroy();continue;}
        }
        
        if(inputData.data["ocrLn"]=="ocrTibetanEnglish"){
            if(!RE2::PartialMatch(glyph->name,"[\\p{Tibetan}\\d\\]\\[«»［］｛｝—⊕\\|\\(\\)\\-\\.,;:\\!\\?=IVX]+")
               &&!RE2::PartialMatch(glyph->name,"[a-zA-Z]+")){glyph->destroy();continue;}
        }
        
        if(inputData.data["ocrLn"]=="ocrTibetanRussian"){
            if(!RE2::PartialMatch(glyph->name,"[\\p{Tibetan}\\d\\]\\[«»［］｛｝—⊕\\|\\(\\)\\-\\.,;:\\!\\?=IVX]+")
               &&!RE2::PartialMatch(glyph->name,"[а-яА-ЯёЁ]+")){glyph->destroy();continue;}
        }
        if(inputData.data["ocrLn"]=="ocrSanskrit"){
            if(!RE2::PartialMatch(glyph->name,"[\\p{Devanagari}\\d\\]\\[«»［］｛｝—⊕\\|\\(\\)\\-\\.,;:\\!\\?=IVX]+")){glyph->destroy();continue;}
        }  
        if(inputData.data["ocrLn"]=="ocrTibetanSanskrit"){
            if(!RE2::PartialMatch(glyph->name,"[\\p{Tibetan}\\d\\]\\[«»［］｛｝—⊕\\|\\(\\)\\-\\.,;:\\!\\?=IVX]+")
               &&!RE2::PartialMatch(glyph->name,"[\\p{Devanagari}]+")){glyph->destroy();continue;}         }
        if(inputData.data["ocrLn"]=="ocrKannada"){
            if(!RE2::PartialMatch(glyph->name,"[ಂ-೯\\d\\]\\[«»［］｛｝—⊕\\|\\(\\)\\-\\.,;:\\!\\?=IVX]+")){glyph->destroy();continue;}         }
        
        //if((aliKali[0][in]->codeSpace>93||aliKali[0][in]->selfCorrelation<97)&&aliKali[0][in]->OCRIndex!=3)continue;   
        //для корреляции не используем неустойчивые буквы
        
        
        if(scaleMode&&glyph->OCRIndex!=5){glyph->destroy();continue;}
        
#ifdef REPORT
        //if(inputData.data["name"]==glyph[0].name){print=1;}else{print=0;}
        //cout<<"/"<<glyph[0].name<<"/check glyph="<<glyph[0].name<<" in="<<in<<" inputData.x1="<<inputData.x1<<" inputData.x0="<<inputData.x0<<END;
        //cout<<(short)glyph[0].name[0]<<endl;
        //if((short)glyph[0].name[0]==58)print=1;
        
        
#endif
        
        
        
        int OCRFlag=0;
        
        letterY0=glyph[0].y0;
        
        if(glyph[0].mask32Count()>0){
            dX=glyph[0].mask32[0].mWOn/2; if(dX<5)dX=5; if(dX>10)dX=10;
            dY=glyph[0].mask32[0].mHOn/2; if(dY<5)dY=5; if(dY>10)dY=10;
            if(dY<dX)dY=dX;  //выбираем наименьший шаг сетки. Необходимо для поиска небольших признаков
            if(dX<dY)dX=dY;
            if(y0==0)y0=nrows/10;
            if(y1==0)y1=nrows-nrows/10-border;	 
            
            limitY=(y1-y0)/1;
			
            maskY0=y0-letterY0+glyph[0].mask32[0].yMask+border-limitY; //
            maskY1=maskY0+limitY*2;
            DR("glyph[0].mask32[0].yMask="<<glyph[0].mask32[0].yMask<<"letterY0="<<letterY0<<" y0="<<y0+border<<" maskY0="<<maskY0<<" border="<<border<<" ncolumns="<<ncolumns<<" limitY="<<limitY<<END)
            
            int xSt=border,xEn=ncolumns-border-32; //выносим вычисления счетчиков за границы цикла
            
            for(int y=maskY0;y<=maskY1;y+=dY){  //DR("//@@@/_y="<<y<<endl)
                for(int x=xSt;x<xEn;x+=dX){ //DR("//@@@/_x="<<x<<endl)
                    
                    mC=0; maxSumX=0;maxSumY=0; count=0;
					for(int m=0;m<glyph[0].mask32Count();m++){
                        maxX=0; maxY=0;
                        
                        if(m==0){
                                
                            
                            mC0=setMatrix_Lion(&glyph[0].mask32[m],
                                               glyph[0].mask32[0].xMask+x,
                                               y,
                                               glyph[0].mask32[0].xMask+x+dX,
                                               y+dY,
                                               0,
                                               &maxX,
                                               &maxY,
                                               0);
                            
                            
                            mX=x+(maxX-glyph[0].mask32[0].xMask-x);
                            mY=y+(maxY-glyph[0].mask32[0].yMask-y);
                            if(mC0>-1)DR("@mC0="<<mC0<<" x="<<maxX-32<<" y="<<maxY<<endl)
                            if(mC0<75&&OCRMode==1)break;
                            if(mC0<40&&OCRMode==2)break;
                            //tm_end=clock(); tm_end-=tm_start; tm0+=tm_end;
                        }else{
                            //tm_start=clock();
                            
                            mC0=setMatrix_Lion(&glyph[0].mask32[m],
                                               glyph[0].mask32[m].xMask+mX,
                                               glyph[0].mask32[m].yMask+mY,
                                               0,0,
                                               deltaSearch,
                                               &maxX,
                                               &maxY,
                                               0);
                            //DR("t2")
							//tm_end=clock(); tm_end-=tm_start; tm1+=tm_end;
                        }
                        
                        //#ifdef REPORT
                        //if(print)glyph[0].mask32[m].printMask();
                        //DR("mask"<<m<<" mC0="<<mC0<<" x="<<x<<" y="<<y<<" glyph y="<<glyph[0].mask32[m].yMask)
                        //DR("__________________MatrixCorrelation="<<mC0<<" glyph[0].name="<<glyph[0].name.c_str())
                        //DR(" mask["<<m<<"].mHOn="<<glyph[0].mask32[m].mHOn)
                        DR("   maxX="<<maxX<<" maxY="<<maxY<<" mC0="<<mC0<<END)
                        //#endif
                        //при распознавании печатного текста выходим из проверки буквы
                        //после второй нераспознанной маски 
                        if(mC0<75&&OCRMode==1){
                            OCRFlag++;
                            if(OCRFlag==2){
                                OCRFlag=0;
                                goto nextLetterPosition; 
                            }                               
                        }
                        //if(mC0<50&&OCRMode==2){
                        //    OCRFlag++;
                        //    if(OCRFlag==2){
                        //        OCRFlag=0;
                        //        goto nextLetterPosition;
                        //    }
                        //}
						
                        mC+=mC0;
                        maxSumX+=maxX+glyph[0].mask32[m].imgW/2;
                        maxSumY+=maxY+glyph[0].mask32[m].mH/2;;
                        count++;
                        
                    }//for(int m=0;m<glyph[0].mask32Count
                    //DR("t3")
                    mC/=glyph[0].mask32Count();
                    if(count){
#ifdef REPORT
                        DR("/_ALL MatrixCorrelation/_____________________________________________mC="<<mC<<" maxSumX="<<maxSumX/count-32<<" count="<<count<<END)
#endif
                        maxSumX=maxSumX/count-32;
                        maxSumY=maxSumY/count;
                        //if(maxSumX<0)maxSumX=0;
                        //if(maxSumX>matchLine.size())maxSumX=matchLine.size()-1;
                        //maxSumX=glyph[0].xSum+maxSumX-border+16-glyph[0].letterW/2;
                        //maxSumX=maxSumX-glyph[0].xSum; 
                        
                        DR("maxSumX="<<maxSumX<<" border="<<border<<" glyph[0].xSum="<<glyph[0].xSum)
                        
                        
                        
                    }
                    //SH(mC);
                    //ImageProcessor->WriteImageData(drawDataRGB,IMGNOFLIP);
#ifdef REPORT
                    if(mC>0)DT("ALL mC="<<mC<<" y="<<maxSumY<<" x="<<maxSumX<<" glyph[0].ySum="<<glyph[0].ySum<<END);
                    if(inputData.idNumber==in){
                        if(mC>mCMax){mCMax=mC; name=glyph[0].name;}
                    }
#endif
                    if(!maxSumX)continue;
                    //DT("t4 maxSumX="<<maxSumX);
                    if(mC>50){
                        //cout<<"set c0="<<matchLine[maxSumX].correlation;
                        //возможна по этому адресу уже есть буква, например огласовка.
                        //проверяем и если это так вставляем букву перед огласовкой
                        //maxSumX+=glyph[0].dX; DT(" glyph[0].dX="<<glyph[0].dX<<endl);
                        
                        if(maxSumX>matchLine.size()-1||maxSumX<0){cout<<"OUT_OF_RANGE1"<<" maxSumX="<<maxSumX<<"name="<<glyph[0].name<<" index ="<<in<<endl;
                            for(int t=0;t<glyph[0].mask32Count();t++){
                                cout<<"x"<<t<<"="<<glyph[0].mask32[t].xMask<<endl;
                            }continue;
                        }
                        xCenter=maxSumX;
                        
                        if(matchLine[maxSumX].OCRIndex==3&&glyph[0].OCRIndex!=3){
                            maxSumX--;
                        }
                        if(matchLine[maxSumX].OCRIndex==3&&glyph[0].OCRIndex!=3){
                            maxSumX--;
                        }
                        if(matchLine[maxSumX].OCRIndex==3&&glyph[0].OCRIndex!=3){
                            maxSumX--;
                        }
                        if(matchLine[maxSumX].OCRIndex!=3&&glyph[0].OCRIndex==3){
                            maxSumX++;
                        }
                        if(matchLine[maxSumX].OCRIndex!=3&&glyph[0].OCRIndex==3){
                            maxSumX++;
                        }
                        if(matchLine[maxSumX].OCRIndex!=3&&glyph[0].OCRIndex==3){
                            maxSumX++;
                        }
                        
                        
                        if(matchLine[maxSumX].correlation==mC){
                            maxSumX++;
                        }
                        if(matchLine[maxSumX].correlation==mC){
                            maxSumX++;
                        }
                        if(matchLine[maxSumX].correlation==mC){
                            maxSumX++;
                        }
                        
                        /*if(matchLine[maxSumX].correlation==mC){
                         OCRMatch match;
                         match.correlation=mC;
                         match.name=glyph[0].name;
                         match.Wylie=glyph[0].Wylie;
                         match.OCRIndex=glyph[0].OCRIndex;
                         match.letterIndex=in;
                         match.maxY=maxSumY;
                         matchLine[maxSumX].match.push_back(match);
                         }
                         */
                        
                        /*
                         static index=0;
                         cout<<"letter_"<<in<<" index_"<<index<<" maxSumX="<<maxSumX<<END;
                         if(index>4){
                         int a=0;
                         cout<<"name="<<glyph[0].name<<END;
                         }index++;
                         */
                        
                        if(matchLine[maxSumX].correlation<mC){
                            OCRMatch match;
                            DR("set in="<<in<<" c0="<<mC<<"maxSumX="<<maxSumX-border<<"name="<<glyph[0].name<<endl)
                            match.correlation=mC;
                            match.status=0;
                            match.name=glyph[0].name;
                            match.OCRIndex=glyph[0].OCRIndex;
                            match.letterIndex=in;
                            match.letterW=glyph->letterW;
                            match.letterH=glyph->letterH;
                            match.yCenter=maxSumY-border;
                            match.xCenter=maxSumX-border;
                            match.lineIndex=lineIndex;
                            matchLine[maxSumX]=match;
                        }
                    }//if(mC>50
                    //DT("t5");	
                nextLetterPosition:;
                    
                }//for(int x=border+32
                DR("/t6/___"<<endl)
            }//for(int y=maskY0;
            DR("/t7/___"<<endl)
        }//if(glyph[0].mask32Count
        glyph->destroy();
        
    }//for(int in=0; in<aliKali->base.size();
    
#ifdef REPORT
    DR("/@@@/___ALL mCMax="<<mCMax<<" name="<<name<<END)
#endif
#ifdef MMX    
    __asm {emms;}
#endif
    //cout<<"tm0="<<(double)tm0/CLOCKS_PER_SEC<<" tm1="<<(double)tm1/CLOCKS_PER_SEC<<" tm0/tm1="<<(double)tm0/tm1<<END;
	// emms; команда обеспечивает переход процессора от исполнения MMX-команд
	// к исполнению обычных команд с плавающей запятой:
	// она устанавливает значение 1 во всех разрядах слова состояния.
    
	//DM("2@@")tm_end=clock(); tm_end-=tm_start; time=tm_end/CLOCKS_PER_SEC;DM("time="<<time<<END);
	//DP("Matrix_Lion_2@@")tm_end=clock(); tm_end-=tm_start1; time=tm_end/CLOCKS_PER_SEC;DP("time="<<time<<END<<END);
    /**/
    
    //#ifdef WIN32
    //ImageProcessor->WriteImageData(drawDataRGB,IMGNOFLIP);  //SH(1);
    //#endif
    // TIME_PRINT
    
#undef c_out_
    
    
}//_____________________________________________________________________________


