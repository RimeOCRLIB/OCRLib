#include "GBitsetMatrix.h"
#include "php2stl.h"
#define REPORT

//функция сравнения параметров двух линий
inline int GBitsetMatrix::lineCorrelation(OCRFocalLine &textLine,OCRFocalLine &baseLine,OCRPoint &center,uint &indexLine){
    int print=0;
    int correlationPoints=0;
    int alpha=baseLine.alpha;
    int corA=baseLine.corA;
    int corL=baseLine.corL;
    int lenA=baseLine.lenA;
    ostringstream out;
    
    if(inputData.start==100){
        print=1;
    }

    DR("    /<<"<<indexLine<<"/____ x_="<<center.x<<" y_="<<center.y<<" alpha="<<alpha<<" corA="<<corA<<" corL="<<corL<<endl);
    DR("            baseLine start="<<(short)baseLine.start.type<<" baseLine end="<<(short)baseLine.end.type<<endl);
    DR("            textLine.centerM.x="<<textLine.centerM.x/10<<" textLine.centerM.y="<<textLine.centerM.y/10<<endl);
    
    
    //проверка совпадения линий по координате Y центров масс линий
    if(abs(textLine.centerM.y/10-center.y)<15){
        DR("    y match"<<" textLine alpha="<<textLine.alpha<<" corA="<<textLine.corA<<" corL="<<textLine.corL<<endl);
        
        //проверка совпадения абсолютных углов линий. Разница не должна превышать 20 градусов
        int a1=abs(textLine.alpha-alpha);
        int lineRevers=0;   //флаг указывает что линии повернуты на 180 градусов
        if(a1>90){a1=abs(a1-180); lineRevers=1;}
        if(a1<20){
            correlationPoints+=25*((float)(90-a1)/90);
        }
#ifdef REPORT        
        if(print)out<<"alpha cor="<<correlationPoints<<" = "<<(int)(100*(float)correlationPoints/25)<<"%"<<endl;
#endif
        //если углы не совпадают и одна из линий это прямая линия прекращаем проверку
        if(!correlationPoints&&(corA<70||textLine.corA<70))return 0;
        
        //в случае если одна из линий это кривая Безье то сравниваем харакетеристики кривых Безье
        if(textLine.corA>70||corA>70){
            DR("            alphaP1="<<textLine.alphaP1<<" alphaP2="<<textLine.alphaP2<<" alphaP1_="<<baseLine.alphaP1<<" alphaP2_="<<baseLine.alphaP2<<endl);
            DR("            lenP1="<<textLine.lenP1<<" lenP2="<<textLine.lenP2<<" lenP1_="<<baseLine.lenP1<<" lenP2_="<<baseLine.lenP2<<endl);
            int p1;
            int p2;
            
            //если линни совпадают по направлению
            if(!lineRevers){
                p1=abs(textLine.alphaP1-baseLine.alphaP1);  //разность абсолютных углов точек Безье 1
                p2=abs(textLine.alphaP2-baseLine.alphaP2);  //разность абсолютных углов точек Безье 2
            }else{
                //если линни повернуты на 180 градусов
                p1=abs(textLine.alphaP1-baseLine.alphaP2);  //разность абсолютных углов точек Безье 1
                p2=abs(textLine.alphaP2-baseLine.alphaP1);  //разность абсолютных углов точек Безье 2
            }
            //проверяем разность абсолютных углов управляющих векторов Безье
            int pA=0;
            //проверяем разность абсолютных углов первого вектора Безье
            if(p1<20){
                pA+=20*((float)(90-p1)/90);
            }
            //проверяем разность абсолютных углов второго вектора Безье
            if(p2<20){
                pA+=20*((float)(90-p2)/90);
            }
            //если ни один угол не совпал с точностью до 20 градусов прекращаем проверку
            if(!pA)return 0;
            //проверяем совпадение длинн управляющих векторов Безье
            if(!lineRevers){
                if(abs(textLine.lenP1-baseLine.lenP1)<textLine.len/4)pA+=10;
                if(abs(textLine.lenP2-baseLine.lenP2)<textLine.len/4)pA+=10;
            }else{
                if(abs(textLine.lenP1-baseLine.lenP2)<textLine.len/4)pA+=10;
                if(abs(textLine.lenP2-baseLine.lenP1)<textLine.len/4)pA+=10;
            }
            correlationPoints+=pA;
#ifdef REPORT
            if(print)out<<"Bezier cor="<<pA<<" = "<<(int)(100*(float)pA/60)<<"%"<<endl;
#endif
            
        }else{
          //проверяем совпадение коэфициентов линеарности двух линий
            int lineReport=60*((float)(100-abs(textLine.corL-corL))/100);
          if(abs(textLine.corL-corL)<20)correlationPoints+=lineReport;
#ifdef REPORT
            if(print)out<<"Linear cor="<<lineReport<<" = "<<(int)(100*(float)lineReport/20)<<"%"<<endl;
#endif
        }
        //проверяем совпадение пиксельных длинн двух линий
        int lineCor=0;
        if(abs(textLine.lenA-lenA)<textLine.lenA/2){
            int dL=abs(textLine.lenA-lenA);
            int l=(textLine.lenA+lenA)/2;
            int dL_=l-dL;
            if(dL_>0)lineCor=20*((float)dL_/l);
            correlationPoints+=lineCor;
        }
#ifdef REPORT
        if(print)out<<"Length cor="<<lineCor<<" = "<<(int)(100*(float)lineCor/20)<<"%"<<endl;
#endif
        //проверяем совпадение типов стартовых и конечных точек двух линий
        //совпадение Т-образных и Х-образных точек имеен приоритет
        int pointCor=0;
        DR("test start="<<(short)textLine.start.type<<"test end="<<(short)textLine.end.type<<endl);
        if(!lineRevers){
            if(textLine.start.type==baseLine.start.type){
                if(textLine.start.type!=L_POINT){
                    pointCor+=15;
                }else{
                    pointCor+=5;
                }
            }
            if(textLine.end.type==baseLine.end.type){
                if(textLine.end.type!=L_POINT){
                    pointCor+=15;
                }else{
                    pointCor+=5;
                }
            }
        }else{
            if(textLine.start.type==baseLine.end.type){
                if(textLine.start.type!=L_POINT){
                    pointCor+=15;
                }else{
                    pointCor+=5;
                }
            }
            if(textLine.end.type==baseLine.start.type){
                if(textLine.end.type!=L_POINT){
                    pointCor+=15;
                }else{
                    pointCor+=5;
                }
            }
        }
        correlationPoints+=pointCor;
#ifdef REPORT
        if(print){
            out<<"Points cor="<<pointCor<<" = "<<(int)(100*(float)pointCor/20)<<"%"<<endl;
            out<<correlationPoints<<"_//__ALL CORRELATION"<<endl;
            string report=out.str();
            inputData.data["report"]=report;
        }
#endif
        //приводим результат к 100 процентам
        if(correlationPoints>100)correlationPoints=100;
        
        DR("___"<<correlationPoints<<"_@@match____ alpha="<<textLine.alpha<<" y="<<textLine.centerM.y/10<<endl);
    }

    return correlationPoints;
}


void GBitsetMatrix::letterCorrelation(vector<OCRMatch>&matchLine,
									  GFont *aliKali,
                                      int lineIndex,
									  int y0,
									  int y1,
									  int scaleMode,
                                      int OCRMode,
									  int print){

#ifdef REPORT
DR("inputData.name"<<inputData.data["name"]<<" border="<<border<<END)
int mCMax=0; string name;
#endif

  int mC,mC0,dX,dY,mY,mX;
  int maxX,maxY,maxSumX,maxSumY,count;
  int letterY0, maskY0, maskY1,limitY;    //, xCenter;
  GLetter *glyph;
    
// переход в режим Assembler, загрузка констант
#if defined ASM_OS64_SSE3 || defined ASM_OS32_SSE2

__asm{     //  movups (без требования выравнивания)
	/// Для выполнения в регистрах MMX
#ifdef MMX	
	// загрузка констант в регистр 64p ММХ ( считаем в байтах - int*4)
	movq            mm5, qword ptr constF+16;   // 55 Пересылка данных (64 бит)
	movq            mm6, qword ptr constF;      // 33 из/в регистр ММХ  MOVDQU-128
	movq            mm7, qword ptr constF+32;   // 0f
#endif
	// загрузка констант в регистр 128p SSE
	//  movups без требования выравнивания  ( MOVAPS должны быть выровнены )
#ifdef WIN32
	//Vic movups          xmm5, dqword ptr constF+16;  // 55  Пересылка данных (128 бит)
	//Vic movups          xmm6, dqword ptr constF;     // 33  + MOVDQU
	//Vic movups          xmm7, dqword ptr constF+32;  // 0f
//	movups          xmm2, dqword ptr constF+48;  // TEST
#else
        movups          xmm5, [constF+16];  // 55  Пересылка данных (128 бит)
        movups          xmm6, [constF+0];     // 33  + MOVDQU
        movups          xmm7, [constF+32];  // 0f
	//movups          xmm2, dqword ptr constF+48;  // TEST
#endif

}; // __asm
    //Инструкция movq выполняется за шесть тактов, тогда как для pshufw требуется только два
    /**/
#endif   
	
    
//TIME_START
    
OCRMode=1;
    
int deltaSearch;
int correlationLimit=70;

if(OCRMode==1)deltaSearch=8;
if(OCRMode==2)deltaSearch=8;
if(OCRMode==3)deltaSearch=8;
  

//unsigned long long  tm_start0, tm_end0; double time0=0;    
//unsigned long long  tm_start1, tm_end1; double time1=0;  
//unsigned long long  tm_start2, tm_end2; double time2=0; 
//pTicks tcs;
//int tCount=0;
    
    //установка лимита поиска по фокальным точкам
    //поиск осуществляется по точкам центров масс фокальных линий
    limitY=(y1-y0);
    
    /*
    if(OCRMode==1||OCRMode==2||OCRMode==3){
        for(int pointIndex=0;pointIndex<focalPoint.size();pointIndex++){
            if(fPoint[pointIndex].type==L_POINT||fPoint[pointIndex].y-border>y1+limitY*2||fPoint[pointIndex].y-border<y0-limitY){
               //drawPoint[0][fPoint[pointIndex].y][fPoint[pointIndex].x]=255;
               fPoint[pointIndex].status=0;
            }else{
               fPoint[pointIndex].status=1;
            }   
            //cout<<" y="<<fPoint[pointIndex].y-border<<" y0="<<y0<<" y1="<<y1<<endl;
        }  
    }
    */

 
    //TIME_START
    //float maxTime=0; int maxTimeIndex=0;
    
	 for(int in=1; in<aliKali->letterCount();in++){  
         
#ifdef REPORT
         if(inputData.start==101){
              if(in!=inputData.startIndex)continue; //print=1;    //12091
         }
#endif
         //print=0; if(in==16319)print=1;  if(!print)continue;     //16319/=yatag  //9249 ra
         
         glyph=aliKali->getLetter(in);
         glyph[0].OCRIndex=glyph[0].OCRKey[0];
         
         //if(glyph->name!="ྱ"){glyph->destroy();continue;} //print=1;
         //if(glyph->OCRKey[0]=='V'){glyph->destroy();continue;}

         if(glyph->mask32Count()==0||!glyph->recordStatus){glyph->destroy();continue;}
         
         //cout<<" in="<<in<<" name"<<glyph->name<<" "<<glyph->OCRKey.size();

         //if(scaleMode&&glyph->OCRIndex!=5){glyph->destroy();continue;}
		 
         int OCRFlag=0;

		 letterY0=-glyph[0].letterH/2;
         DR("glyph["<<in<<"].OCRKey="<<glyph[0].OCRKey<<" type="<<(int)glyph[0].fPoint[0].type<<" pCount"<<glyph[0].fPointCount()<<endl)
          //||OCRMode==2
         if((OCRMode==1)&&glyph[0].focalLine.size()){  // glyph[0].OCRKey[0]!='X'&&glyph[0].OCRKey[0]!='Z' //||OCRMode==2
             
             //если в букве есть фокальные линии то поиск ведем перебором центров масс фокальных линий на странице.
             //Положение первого признака отсчитываем от положения центра масс фокальной линии.
             int xPointLetter=glyph[0].fLine[0].centerM.x/10;
             int yPointLetter=glyph[0].fLine[0].centerM.y/10;
             int fLineCorrelation=0;
             int lineCount=(uint)glyph[0].focalLine.size();
             
             for(int pointIndex=0;pointIndex<focalLine.size();pointIndex++){
                 
                 int xCenter=fCenter[pointIndex].x-xPointLetter;
                 int yCenter=fCenter[pointIndex].y-yPointLetter;
                
                 //drawData[0][yCenter][xCenter]=0;
                 DR("i="<<pointIndex<<" x="<<fCenter[pointIndex].x<<" y="<<fCenter[pointIndex].y<<endl);
                 
                 int pointsCorrelation=1;
                 //проверяем остальные точки.
                 int letterLineLen=glyph[0].fLine[0].lenA;
                 int correlationLineLen=letterLineLen;
                 
                 if(lineCount>1){
                     for(int pIndexLetter=1;pIndexLetter<lineCount;pIndexLetter++){
                         int x_=xCenter+glyph[0].fLine[pIndexLetter].centerM.x/10;
                         int y_=yCenter+glyph[0].fLine[pIndexLetter].centerM.y/10;
                         letterLineLen+=glyph[0].fLine[pIndexLetter].lenA;
                         //cout<<" l_="<<glyph[0].fLine[pIndexLetter].lenA<<endl;
                         if(drawPoint[y_][x_]<255){
                             //drawPoint[0][y_][x_]=0;
                             //cout<<" Get it!";
                             pointsCorrelation+=2;
                             correlationLineLen+=glyph[0].fLine[pIndexLetter].lenA;
                         }
                     }
                 }
                 DR("    pointsCorrelation="<<pointsCorrelation<<" correlationLineLen="<<correlationLineLen<<" letterLineLen="<<letterLineLen<<endl);
                     
                 if(correlationLineLen>letterLineLen/10){
                     //Для найденной буквы совпадающей по точкам проверяем корреляцию по фокальным линиям.
                     OCRFocalLine *vLine=(OCRFocalLine*)&glyph[0].focalLine[0];
                     int fCount=(uint)glyph[0].focalLine.size();
                     fLineCorrelation=0;
                     DR("  @@_ letter in="<<in<<"___________"<<"xCenter="<<xCenter<<"_____________________________"<<endl);
                     for(int vIndex=0;vIndex<fCount;vIndex++){
                         OCRPoint p;
                         p.x=xCenter+vLine[vIndex].centerM.x/10;
                         p.y=yCenter+vLine[vIndex].centerM.y/10;
                         DR("    @@__/Test line vIndex="<<vIndex<<" p.x="<<p.x<<" p.y="<<p.y<<" alpha="<<vLine[vIndex].alpha<<endl);
                         if(p.x==1076&&p.y==225){
                             //inputData.start=100;
                             int v=0;
                         }
                         
                         if(vIndex==0){
                             //первый линию устанавливаем по центру тестовой линии проверяем на возможность установки буквы.
                             int flag=0;
                             int count=line2D[p.x][0];
                             int correlation;
                             for(int k=0;k<count;k++){
                                 uint indexLine=line2D[p.x][k+1];
                                 correlation=lineCorrelation(focalLine[indexLine],vLine[vIndex],p,indexLine);
                                 //DR("    @@c="<<correlation<<endl);
                                 if(correlation>70){flag++;break;}
                             }
                             //если первая линия буквы не совпала, букву на этом месте не проверяем
                             if(!flag)break;
                             fLineCorrelation+=correlation*((float)vLine[0].lenA/letterLineLen);
                             continue;
                         }
                         
                         
                         int dl=0;
                         //проверяем линии на расстоянии 15 пикселов  в обе стороны от исходных координат центра масс тестовой линии
                         while(dl<15){
                             int count=line2D[p.x-dl][0];
                             //if(count)cout<<line2D[x_-dl][0]<<endl;
                             for(int k=0;k<count;k++){
                                 uint indexLine=line2D[p.x-dl][k+1];
                                 int correlation=lineCorrelation(focalLine[indexLine],vLine[vIndex],p,indexLine);
                                 //DR("    @@c="<<correlation<<endl);
                                 if(correlation>70){
                                     fLineCorrelation+=correlation*((float)vLine[vIndex].lenA/letterLineLen);
                                     goto continueFor;
                                 }
                             }
                             count=line2D[p.x+dl][0];
                             for(int k=0;k<count;k++){
                                 uint indexLine=line2D[p.x+dl][k+1];
                                 int correlation=lineCorrelation(focalLine[indexLine],vLine[vIndex],p,indexLine);
                                 //DR("    @@c="<<correlation<<endl);
                                 if(correlation>70){
                                     fLineCorrelation+=correlation*((float)vLine[vIndex].lenA/letterLineLen);
                                     goto continueFor;
                                 }
                             }
                             dl++;
                         }
                         continueFor:;
                     }
                     //if(fCount)fLineCorrelation=fLineCorrelation/fCount;
                     DR(fLineCorrelation<<"_///////@@@/ALL line correlation of letter in="<<in<<" fCount="<<fCount<<endl<<endl);
                     if(fLineCorrelation<70)continue;
                     //cout<<" pC="<<pointsCorrelation<<endl;
#ifdef REPORT
                     if(inputData.start>0){
                         inputData.lineIndex.push_back(pointIndex);
                     }
                     //print =0;if(in==16672)print=1;
#endif
                     //Проверяем битовую корреляцию буквы относительно найденного центра буквы.
                     dX=glyph[0].mask32[0].mWOn; if(dX<10)dX=10; //if(dX>14)dX=16;
                     dY=glyph[0].mask32[0].mHOn; if(dY<10)dY=10; //if(dY>14)dY=16;
                     //if(dY>dX)dY=dX;  //выбираем наименьший шаг сетки. Необходимо для поиска небольших признаков
                     //if(dX>dY)dX=dY;
                     
                     mC=0; maxSumX=0;maxSumY=0; count=0;
                     
                     for(int m=0;m<glyph[0].mask32Count();m++){
                         maxX=0; maxY=0;
                         
                         if(m==0){  
                             
                             //asm("rdtsc\n": "=a"(tcs.dw.tl),"=d"(tcs.dw.th));  tm_start1=tcs.tx;  //### 
                             
                             mC0=setMatrix_Lion(&glyph[0].mask32[m],
                                                glyph[0].mask32[0].xMask+xCenter-dX/4+32,
                                                glyph[0].mask32[0].yMask+yCenter-dY/4,
                                                glyph[0].mask32[0].xMask+xCenter+dX/4+32,
                                                glyph[0].mask32[0].yMask+yCenter+dY/4,
                                                0,
                                                &maxX,
                                                &maxY,
                                                0);
                             
                             
                             mX=xCenter+(maxX-glyph[0].mask32[0].xMask-xCenter);
                             mY=yCenter+(maxY-glyph[0].mask32[0].yMask-yCenter);
                             if(mC0>-1)DR2("@mC0="<<mC0<<" x="<<maxX-32<<" y="<<maxY<<endl)
                            
#ifdef DEBUGLVL_DRAW        
                           if(mC0>0){
                             for(int t=0;t<dY;t++){
                                 for(int d=0;d<dX;d++){
                                     //drawData[0][maxY+t][glyph[0].mask32[0].xMask+xCenter-dX/2+d]/=(mC0+1);
                                     //drawDataRGB->put(glyph[0].mask32[0].xMask+xCenter-dX/2+d,maxY+t,0xFF000000);
                                 }        
                             }
                           }
#endif                       
                             //asm("rdtsc\n": "=a"(tcs.dw.tl),"=d"(tcs.dw.th));  tm_end1=tcs.tx;
                             //tm_end1-=tm_start1; time1+=(double)tm_end1/3000000000;  //###
                             //tCount++;
                             
                             if(mC0<75&&OCRMode==1&&fLineCorrelation<80)goto nextLetterPoint;
                             if(mC0<40&&OCRMode==2)goto nextLetterPoint;
                         }else{
                             //asm("rdtsc\n": "=a"(tcs.dw.tl),"=d"(tcs.dw.th));  tm_start2=tcs.tx;  //### 

                             mC0=setMatrix_Lion(&glyph[0].mask32[m],
                                                glyph[0].mask32[m].xMask+mX,
                                                glyph[0].mask32[m].yMask+mY,
                                                0,0,
                                                deltaSearch,
                                                &maxX,
                                                &maxY,
                                                0);
                             //asm("rdtsc\n": "=a"(tcs.dw.tl),"=d"(tcs.dw.th));  tm_end2=tcs.tx;
                             //tm_end2-=tm_start2; time2+=(double)tm_end1/3000000000;  //###

                             //DR("t2")
                         }
                         
                         //#ifdef REPORT
                         //if(print)glyph[0].mask32[m].printMask();
                         //DR("mask"<<m<<" mC0="<<mC0<<" x="<<x<<" y="<<y<<" glyph y="<<glyph[0].mask32[m].yMask)
                         //DR("__________________MatrixCorrelation="<<mC0<<" glyph[0].name="<<glyph[0].name.c_str())
                         //DR(" mask["<<m<<"].mHOn="<<glyph[0].mask32[m].mHOn)
                         DR2("   maxX="<<maxX<<" maxY="<<maxY<<" mC0="<<mC0<<END)
                         //#endif
                         //при распознавании печатного текста выходим из проверки буквы
                         //после второй нераспознанной маски 
                         if(mC0<75&&OCRMode==1&&fLineCorrelation<80){
                             OCRFlag++;
                             if(OCRFlag==2){
                                 OCRFlag=0;
                                 goto nextLetterPoint; 
                             }                               
                         }
                         //if(mC0<50&&OCRMode==2){
                         //    OCRFlag++;
                         //    if(OCRFlag==2){
                         //        OCRFlag=0;
                         //        goto nextLetterPosition;
                         //    }
                         //}
                         
                         mC+=mC0;
                         maxSumX+=maxX-glyph[0].mask32[m].xMask;         //подсчет среднего положения буквы
                         maxSumY+=maxY-glyph[0].mask32[m].yMask;
                         glyph[0].mask32[m].xMax=maxX-32;              //сохраняем позиции найденных признаков
                         glyph[0].mask32[m].yMax=maxY;
                         count++;
                         
                     }//for(int m=0;m<glyph[0].mask32Count
                     //DR("t3")
                     mC/=glyph[0].mask32Count();
                     if(count){
#ifdef REPORT
DR("/_ALL MatrixCorrelation/_________________________mC="<<mC<<" maxSumX="<<maxSumX/count-32-border<<" maxSumY="<<maxSumY/count-border<<" count="<<count<<" name="<<glyph[0].name<<END)
#endif
                         maxSumX=maxSumX/count-32;
                         maxSumY=maxSumY/count;
                         //if(maxSumX<0)maxSumX=0;
                         //if(maxSumX>matchLine.size())maxSumX=matchLine.size()-1;
                         //maxSumX=glyph[0].xSum+maxSumX-border+16-glyph[0].letterW/2;
                         //maxSumX=maxSumX-glyph[0].xSum; 
                         
                         DR("maxSumX="<<maxSumX<<" border="<<border<<" glyph[0].xSum="<<glyph[0].xSum)
                         
                         
                         
                     }
                     //SH(mC);
                     //ImageProcessor->WriteImageData(drawDataRGB,IMGNOFLIP);
                     mC=((mC+fLineCorrelation)/2+max(mC,fLineCorrelation))/2;
                     
#ifdef REPORT
                     if(mC>0)DR("ALL mC="<<mC<<" y="<<maxSumY<<" x="<<maxSumX<<" glyph[0].ySum="<<glyph[0].ySum<<END)
                     if(inputData.idNumber==in){
                         if(mC>mCMax){mCMax=mC; name=glyph[0].name;}
                     }
#endif
                     if(!maxSumX)continue;
                     //DR("t4 maxSumX="<<maxSumX)
                     
                     if(mC>correlationLimit){
                         OCRMatch match;
                         DR("set in="<<in<<" i="<<matchLine.size()<<" c0="<<mC<<" maxSumX="<<maxSumX-border<<"name="<<glyph[0].name<<endl)
                         match.correlation=mC;
                         match.status=0;
                         match.name=glyph[0].name;
                         match.OCRIndex=glyph[0].OCRIndex;
                         match.letterIndex=in;
                         match.letterW=glyph->letterW;
                         match.letterH=glyph->letterH;
                         match.yCenter=maxSumY-border+glyph->dY;
                         match.xCenter=maxSumX-border+glyph->dX;
                         match.dX=glyph->dX; match.dY=glyph->dY;
                         match.y0=0;  //указание для setSize()
                         for(int n=0;n<glyph->mask32Count();n++)match.mask32Vector.push_back(glyph[0].mask32[n]);
                         match.lineIndex=lineIndex;
                         match.setSize();
                         matchLine.push_back(match);
                         
                     }//if(mC>50
                     //DR("t5")	
                     
                     
                 }
             nextLetterPoint:; 
             }
             
             //exit(0);
             
             
             
         }else{  
             //проверяем каждую возможную позицию первого признака. 
             //Когда находим первый признак, ищем остальные признаки относительно гипотезы положения первого признака
             dX=glyph[0].mask32[0].mWOn*.75; if(dX<10)dX=10; //if(dX>10)dX=10;   //.75 необходимо для распознавания тонких штрихов
             dY=glyph[0].mask32[0].mHOn*.75; if(dY<10)dY=10; //if(dY>10)dY=10;
             //if(dY>dX)dY=dX;  //выбираем наименьший шаг сетки. Необходимо для поиска небольших признаков
             //if(dX>dY)dX=dY;
             maskY0=y0-letterY0+glyph[0].mask32[0].yMask+border-20; //лимит поиска строится от координат и высоты строки  y0 y1
             maskY1=y1-letterY0+glyph[0].mask32[0].yMask+border+40;  
             
             if(glyph[0].OCRIndex=='A'){ 
                 maskY0=y0-letterY0+glyph[0].mask32[0].yMask+border-15; //лимит поиска строится от координат и высоты строки  y0 y1
                 maskY1=nrows-border+letterY0+glyph[0].mask32[0].yMask;  
             }
             if(glyph[0].OCRIndex=='V'){ 
                 maskY0=y0-glyph[0].letterH*1.5+glyph[0].mask32[0].yMask+border-25; //лимит поиска строится от координат и высоты строки  y0 y1
                 if(maskY0<border)maskY0=border;
                 //maskY1=y0-glyph[0].letterH+glyph[0].mask32[0].yMask+border+25;
                 maskY1=nrows-border+letterY0+glyph[0].mask32[0].yMask;
             }
             if(glyph[0].OCRIndex=='Z'&&glyph[0].name!="|"){ 
                 maskY0=y0-letterY0+glyph[0].mask32[0].yMask+border-15; //лимит поиска строится от координат и высоты строки  y0 y1
                 maskY1=y1-letterY0+glyph[0].mask32[0].yMask+border+15;  
             }
             if(glyph[0].OCRIndex=='R'||glyph[0].OCRIndex=='W'){ 
                 maskY0=y1-letterY0+glyph[0].mask32[0].yMask+border-15; //лимит поиска строится от координат и высоты строки  y0 y1
                 maskY1=nrows-border+letterY0+glyph[0].mask32[0].yMask;  
             }
             if(glyph[0].OCRIndex=='X'){ 
                 maskY0=y0-letterY0+glyph[0].mask32[0].yMask+border-20; //лимит поиска строится от координат и высоты строки  y0 y1
                 maskY1=y1-letterY0+glyph[0].mask32[0].yMask+border+40;    
             }
             if(glyph[0].name=="|"){ 
                 maskY0=border; //лимит поиска строится от координат и высоты строки  y0 y1
                 maskY1=nrows-border+letterY0;    
             }

             
             DR("glyph[0].mask32[0].yMask="<<glyph[0].mask32[0].yMask<<"letterY0="<<letterY0<<" y0="<<y0+border<<" maskY0="<<maskY0<<" maskY1="<<maskY1<<" border="<<border<<" ncolumns="<<ncolumns<<" limitY="<<limitY<<" dX="<<dX<<" dY="<<dY<<" mW="<<glyph[0].mask32[0].mWOn<<END)
             int xSt=border+32,xEn=ncolumns-border+32; //выносим вычисления счетчиков за границы цикла
             
             for(int y=maskY0;y<=maskY1;y+=dY){  //DR("//@@@/_y="<<y<<endl)
                 for(int x=xSt;x<xEn;x+=dX){ //DR("//@@@/_x="<<x<<endl)
                
                    mC=0; maxSumX=0;maxSumY=0; count=0;
                    
                    for(int m=0;m<glyph[0].mask32Count();m++){
                            maxX=0; maxY=0;
                            
                            if(m==0){   
                               //asm("rdtsc\n": "=a"(tcs.dw.tl),"=d"(tcs.dw.th));  tm_start1=tcs.tx;  //###    
                                
                               mC0=setMatrix_Lion(&glyph[0].mask32[m],
                                                   glyph[0].mask32[0].xMask+x,
                                                   y,
                                                   glyph[0].mask32[0].xMask+x+dX,
                                                   y+dY,
                                                   0,
                                                   &maxX,
                                                   &maxY,
                                                   0);


                                mX=x+(maxX-glyph[0].mask32[0].xMask-x);
                                mY=y+(maxY-glyph[0].mask32[0].yMask-y);
                                //asm("rdtsc\n": "=a"(tcs.dw.tl),"=d"(tcs.dw.th));  tm_end1=tcs.tx;
                                //tm_end1-=tm_start1; time1+=(double)tm_end1/3000000000;  //###
                                //tCount++;

                                if(mC0>-1)DR2("@mC0="<<mC0<<" x="<<maxX-32<<" y="<<maxY<<endl)
                                //if(mC0<correlationLimit)break;
                                //if(mC0<40&&OCRMode==2)break;
                                if(mC0<correlationLimit&&OCRMode==1)goto nextLetterPosition;
                                if(mC0<40&&OCRMode==2)goto nextLetterPosition;
                            }else{
                                //asm("rdtsc\n": "=a"(tcs.dw.tl),"=d"(tcs.dw.th));  tm_start2=tcs.tx; //###
                                
                                 mC0=setMatrix_Lion(&glyph[0].mask32[m],
                                                   glyph[0].mask32[m].xMask+mX,
                                                   glyph[0].mask32[m].yMask+mY,
                                                   0,0,
                                                   deltaSearch,
                                                   &maxX,
                                                   &maxY,
                                                   0);
//DR("t2")
                                //asm("rdtsc\n": "=a"(tcs.dw.tl),"=d"(tcs.dw.th));  tm_end2=tcs.tx;
                                //tm_end2-=tm_start2; time2+=(double)tm_end2/3000000000;  //###
                            }

                            //#ifdef REPORT
                            //if(print)glyph[0].mask32[m].printMask();
                            //DR("mask"<<m<<" mC0="<<mC0<<" x="<<x<<" y="<<y<<" glyph y="<<glyph[0].mask32[m].yMask)
                            //DR("__________________MatrixCorrelation="<<mC0<<" glyph[0].name="<<glyph[0].name.c_str())
                            //DR(" mask["<<m<<"].mHOn="<<glyph[0].mask32[m].mHOn)
                            DR2("   maxX="<<maxX<<" maxY="<<maxY<<" mC0="<<mC0<<END)
                            //#endif
                        //при распознавании печатного текста выходим из проверки буквы
                        //после второй нераспознанной маски 
                        if(mC0<correlationLimit&&OCRMode==2){
                               OCRFlag++;
                               if(OCRFlag==2){
                                   OCRFlag=0;
                                   goto nextLetterPosition; 
                               }                               
                        }
                        //if(mC0<50&&OCRMode==2){
                        //    OCRFlag++;
                        //    if(OCRFlag==2){
                        //        OCRFlag=0;
                        //        goto nextLetterPosition;
                        //    }
                        //}
                        
                            mC+=mC0;
                            maxSumX+=maxX-glyph[0].mask32[m].xMask;    //подсчет среднего положения буквы
                            maxSumY+=maxY-glyph[0].mask32[m].yMask;
                            glyph[0].mask32[m].xMax=maxX-32;              //сохраняем позиции найденных признаков
                            glyph[0].mask32[m].yMax=maxY;
                            glyph[0].mask32[m].correlation=mC0;

                        count++;

                    }//for(int m=0;m<glyph[0].mask32Count
//DR("t3")
                         mC/=glyph[0].mask32Count();
                         if(count){
                            #ifdef REPORT
                            DR("/_ALL MatrixCorrelation/_______________________________mC1="<<mC<<" maxSumX="<<maxSumX/count-32-border
                               <<" maxSumY="<<maxSumY/count-border<<" count="<<count<<endl);
                            #endif
                            maxSumX=maxSumX/count-32;
                            maxSumY=maxSumY/count;
                             //if(maxSumX<0)maxSumX=0;
                            //if(maxSumX>matchLine.size())maxSumX=matchLine.size()-1;
                            //maxSumX=glyph[0].xSum+maxSumX-border+16-glyph[0].letterW/2;
                            //maxSumX=maxSumX-glyph[0].xSum; 
                             
                             DR2("maxSumX="<<maxSumX<<" border="<<border<<" glyph[0].xSum="<<glyph[0].xSum)
                             


                         }
                         //SH(mC);
                         //ImageProcessor->WriteImageData(drawDataRGB,IMGNOFLIP);
                         #ifdef REPORT
                         if(mC>0)DR2("ALL mC="<<mC<<" y="<<maxSumY<<" x="<<maxSumX<<" glyph[0].ySum="<<glyph[0].ySum<<END)
                         #endif
                         if(!maxSumX)continue;
//DR("t4 maxSumX="<<maxSumX)
                            if(mC>correlationLimit){
                                     OCRMatch match;
                                     DR2("set in="<<in<<" i="<<matchLine.size()<<" c0="<<mC<<"maxSumX="<<maxSumX-border<<"name="<<glyph[0].name<<endl)
                                     match.correlation=mC;
                                     match.status=0;
                                     match.name=glyph[0].name;
                                     match.OCRIndex=glyph[0].OCRIndex;
                                     match.letterIndex=in;
                                     match.letterW=glyph->letterW;
                                     match.letterH=glyph->letterH;
                                     match.yCenter=maxSumY-border+glyph->dY;
                                     match.xCenter=maxSumX-border+glyph->dX;
                                     match.dX=glyph->dX; match.dY=glyph->dY;
                                     match.y0=0; //указание для setSize()
                                     match.lineIndex=lineIndex;
                                     for(int n=0;n<glyph->mask32Count();n++)match.mask32Vector.push_back(glyph[0].mask32[n]);
                                     match.setSize();
                                     matchLine.push_back(match);
                                
                            }//if(mC>50
//DR("t5")	
            nextLetterPosition:;
                    
            }//for(int x=border+32
DR("/t6/___"<<endl)
          }//for(int y=maskY0;
DR("/t7/___"<<endl)
     
       } 

         //asm("rdtsc\n": "=a"(tcs.dw.tl),"=d"(tcs.dw.th));  tm_end0=tcs.tx;
         //tm_end0-=tm_start0; time0+=(double)tm_end0/3000000000;
  
         glyph->destroy();
         
         //tm_end=clock(); tm_end-=tm_start; time=(float)tm_end/CLOCKS_PER_SEC; 
         //if(time>maxTime){maxTime=time; maxTimeIndex=in;}
         
         //exit(0);
	 }//for(int in=0; in<aliKali->base.size();
    //cout<<"maxTime="<<maxTime<<" maxTimeIndex="<<maxTimeIndex<<endl;
    //cout<<"@@@@@time0/________________________time0="<<time0<<END;
    //cout<<"@@@@@time1/________________________time1="<<time1<<END;
    //cout<<"@@@@@time2/________________________time2="<<time2<<END;
    //cout<<"@@@@@tCount/________________________tCount="<<tCount<<END;
    //cout<<" ALL_OCR_LETTER"; TIME_PRINT_    
    
#ifdef MMX    
	 __asm {emms;}
#endif
	// emms; команда обеспечивает переход процессора от исполнения MMX-команд
	// к исполнению обычных команд с плавающей запятой:
	// она устанавливает значение 1 во всех разрядах слова состояния.
/**/

    
//TIME_PRINT_   

#undef c_out_


}//_____________________________________________________________________________

