//
//  loadDB.cpp
//  OCRLib
//
//  Created by dharmabook on 23/07/15.
//
//

#include <stdio.h>
#include "GMemory.h"

static bool sortKeyL(string& d1, string& d2){
    return d1.size() > d2.size();
}

/**bref load table in mmap memory by name and all table index GMap. If table not exist create it in default data path */
void GMemory::loadTable(string &name){
    string pathTable=inputData.data["DATA_DB"]+name;
    if(!is_dir(pathTable.c_str()) ){
        mkdir(pathTable.c_str(), ACCESSPERMS);
    }
    string path=pathTable+"/"+name+".bin";
    tableRecord &rec=table[name];
    rec.data=GVector::create(path);
    rec.status=1;
    rec.name=name;
    GVector *tableVector=rec.data;
    //check data in tabel and import from default source if table is empty
    if(!tableVector->size()){
        path=pathTable+"/"+name+".tab";
        if(is_file(path)){tableVector->importTAB(path); goto EXIT_IF;}
        path=pathTable+"/"+name+".txt";
        if(is_file(path)){tableVector->importTXT(path); goto EXIT_IF;}
        path=pathTable+"/"+name+".XML";
        if(is_file(path)){tableVector->importXML(path); goto EXIT_IF;}
    }
    EXIT_IF:;
}

void GMemory::reloadIndex(tableRecord &rec,int searchField,int searchMode){
    ostringstream out;
    out<<inputData.data["DATA_DB"]<<rec.name<<"/"<<rec.name<<"_"<<searchField<<"_"<<searchMode<<".index";
    string path=out.str();
    remove(path.c_str());
    createIndex(rec, searchField,searchMode);

}

void GMemory::exportAllRecords(string&tableName,string path){
    path+="/";
    path=str_replace("//", "/", path);
    tableRecord &rec=table[tableName];
    if(!rec.status)loadTable(tableName);  //if table not exsist, create it
    GVector*dict=rec.data;
    for(int n=0;n<dict->size();n++){
        TString st;
        dict->getTStr(n,&st);
        string res;
        string fileName=path+st[0]+".txt";
        if(!st.size())continue;
        for(int n=0;n<st.size();n++){
            string s=st[n];
            res+=s+"\n";
        }
        writeText(res, fileName.c_str());
    }
    
};


indexRecord& GMemory::createIndex(tableRecord &rec, int searchField,int searchMode){
    int indexAddress=searchField*INDEX_COUNT+searchMode;
    
    rec.index.resize(indexAddress+1);  //one record for every type of index for every field
    //check index status. if index not exist, create it.
    if(!rec.index[indexAddress].status){
        //cout<<"start create index for "<<searchField<<" field"<<endl;
        ostringstream out;
        out<<inputData.data["DATA_DB"]<<rec.name<<"/"<<rec.name<<"_"<<searchField<<"_"<<searchMode<<".index";
        string path=out.str();
        
        switch(searchMode){
            case LIST_SEARCH:{
                GVector*dictIndex=GVector::create(path);
                GVector*dict=rec.data;
                rec.index[indexAddress].vIndex=dictIndex;
                //cout<<"done dictWords->size()="<<dictWords->size()<<endl;
                if(!dictIndex->size()){
                    uint sizeV=dict->size();
                    cout<<"start reload dictionary key "<<sizeV<<endl;
                    
                    vector<string> vDict;
                    for(uint a=0;a<sizeV;a++){
                        TString st;
                        dict->getTStr(a,&st);
                        vDict.push_back(st[0]);
                    }
                    cout<<"start sort"<<endl;
                    sort(vDict.begin(),vDict.end(),sortKeyL);
                    for(int a=0;a<vDict.size();a++){
                        //cout<<vDict[a].key<<endl;
                        dictIndex->push_back(vDict[a]);
                    }
                    cout<<"done dictWords->size()="<<dictIndex->size()<<" sizeV="<<sizeV<<endl;
                    
                }
                break;
            }
            case HASH_SEARCH:{
                GVector*dict=rec.data;
                GMap*dictIndex=GMap::create(path,dict);
                if(dict->size()>500000){
                    dictIndex->hashLimit=9;
                }else{
                    dictIndex->hashLimit=8;
                }
                rec.index[indexAddress].mIndex=dictIndex;
                //cout<<"done dictWords->size()="<<dictWords->size()<<endl;
                if(!dictIndex->size()){
                    dictIndex->addRecords(dict,0,OCR_DICT_HASH);
                    dictIndex->save();
                    //cout<<"@@@dictionaryGMap->size()="<<dictIndex->size()<<endl;
                }
                break;
            }
            case TEXT_SEARCH:{
                GVector*dict=rec.data;
                GMap*dictIndex=GMap::create(path,dict);
                rec.index[indexAddress].mIndex=dictIndex;
                //cout<<"done dictWords->size()="<<dictWords->size()<<endl;
                if(!dictIndex->size()){
                    dictIndex->addRecords(dict,0,OCR_DICT_WITH_DELIMETERS);
                    dictIndex->save();
                    //cout<<"@@@dictionaryGMap->size()="<<dictIndex->size()<<endl;
                }
                break;
            }

        }
        rec.index[indexAddress].status=1;
        
    }
    return rec.index[indexAddress];

}






/**bref load all databases in mmap memory by request in inputData global structure*/
void GMemory::loadDB(){
    
    string db=inputData.data["db"];
    string ln=inputData.data["ln"];
    string mode=inputData.data["mode"];
    string pathCorpus;
    string path;
    
    aliKali=((GFontEditor*)inputData.fontEditor)->aliKali;  //load font pointer from fontEditor

    
    uint recordNum;

    if(db=="dict"||db=="corpus"){
        
        //load all data for tibetan language processing
        
        //cout<<"@@@TIB";
        //cout<<"keyDict->size()="<<keyDict->size()<<"vectorDict->size()="<<vectorDict->size()<<endl;
        //cout<<"ln="<<inputData.data["ln"];
        if(inputData.data["ln"]=="tib"){
            pathCorpus=inputData.data["dictPath"]+"TibetanCorpus.bin";
        }else{
            pathCorpus=inputData.data["dictPath"]+"KannadaCorpus.bin";
        }
            
    }
    
    if(db=="corpus"){
        vectorCorpus=GVector::create(pathCorpus);
        if(ln=="tib")vectorCorpus->resizeData(10000000,1400);   //10mln records in 1,4 Gb
        if(ln=="kannada")vectorCorpus->resizeData(2000000,300);   //2mln records in 300Mb
        //recordNum=vectorCorpus->size();
        //if(rowsNum!=1)rowsNum=25;
    }
    if(db=="letter"){
        //recordNum=aliKali->letterCount();
        //rowsNum=400;
        //cout_<<"aliKali->letterCount"<<recordNum<<END;
    }
    if(db=="lib"){
        string pathLib=inputData.data["dictPath"]+"/LIBRARY_CATALOG.bin";
        string pathCatalog=inputData.data["dictPath"]+"/LIBRARY_CATALOG.xml";
        vectorLib=GVector::create(pathLib);
        vectorLib->resizeData(100000,140);   //100k records in 140 mb
        recordNum=vectorLib->size();
        if(recordNum==0)vectorLib->importXML(pathCatalog);
        //if(rowsNum!=1)rowsNum=25;
        //cout_<<"vectorLib->size()="<<vectorLib->size(); exit(0);
        
        pathLib=inputData.data["dictPath"]+"/LIBRARY_PATH_CATALOG.bin";
        pathCatalog=inputData.data["dictPath"]+"/LIBRARY_PATH_CATALOG.txt";
        vectorLibPath=GVector::create(pathLib);
        if(ln=="tib")vectorLibPath->resizeData(100000,140);   //100k records in 140 mb
        recordNum=vectorLibPath->size();
        if(recordNum==0)vectorLibPath->importTXT(pathCatalog);
    }
    
    if(mode=="OCR"){
        //read font grammar data
        path=inputData.data["grammar"]+"UniToTibetanBig.bin";
        fontTable=GVector::create(path);
        //cout<<" table->size()="<<fontTable->size()<<endl;
        if(!fontTable->size())fontTable->importXML(inputData.data["uniTablePath"]);
        
        
        path=inputData.data["grammar"]+"UniToTibetanMap.bin";
        fontGMap=GMap::create(path);
        //cout<<"fontGMap->size()="<<fontGMap->size()<<endl;
        if(!fontGMap->size()){fontGMap->addRecords(fontTable,8,OCR_DICT_WITH_DELIMETERS); fontGMap->save();}
        
        
        path=inputData.data["grammar"]+"UniToTibetanStackMap.bin";
        fontStackGMap=GMap::create(path);
        //cout<<"fontStackGMap->size()="<<fontStackGMap->size()<<endl;
        if(!fontStackGMap->size()){fontStackGMap->addRecords(fontTable,5,OCR_DICT_WITH_DELIMETERS); fontStackGMap->save();}
        
        path=inputData.data["grammar"]+"textCorpus.bin";
        textCorpus=GVector::create(path);
        //cout<<"textCorpus->size()="<<textCorpus->size()<<endl;
        path=inputData.data["grammar"]+"textDict_YagpoUni.txt";
        if(!textCorpus->size())textCorpus->importTXT(path);
        
        path=inputData.data["grammar"]+"textCorpusGMap.bin";
        textCorpusGMap=GMap::create(path,textCorpus);
        //cout<<"textCorpusGMap->size()="<<textCorpusGMap->size()<<endl;
        path=inputData.data["grammar"]+"textDict_YagpoUni.txt";
        if(!textCorpusGMap->size()){
            textCorpusGMap->addRecords(path,OCR_DICT_NO_DELIMETERS);
            textCorpusGMap->save();
            //cout<<"@@@textCorpusGMap->size()="<<textCorpusGMap->size()<<endl;
        } // изготовление словаря
        
        
        //cout<<"textCorpusGMap->size()="<<textCorpusGMap->size()<<endl;
        path=inputData.data["grammar"]+"/textDict_YagpoUni.txt";
        if(!textCorpusGMap->size()){
            textCorpusGMap->addRecords(path,OCR_DICT_NO_DELIMETERS);
            textCorpusGMap->save();
            //cout<<"@@@textCorpusGMap->size()="<<textCorpusGMap->size()<<endl;
        } // изготовление словаря
    }
    
}