#include "GLogicProcessor.h"
#include "GImageEditor.h"
#include "php2stl.h"

/** @brief  функция проверки взаимного положения пары букв  */

void GLogicProcessor::testStackLetter(vector<OCRMatch>&line,GBitmap* lineImg32,GBitmap* letterAImg,GBitmap* letterBImg){
    
    int print=0;
    int index;
    int dX=32;
    int dX_=dX/3;
    int dCMax=12;
    string xKey; xKey=(char)0xE0; xKey+=(char)0xBC; xKey+=(char)0xB9;
    
    //стираем огласовки и приписные буквы
    for(int i=0;i<line.size();i++){
        if(line[i].OCRIndex=='V'||line[i].OCRIndex=='R'||line[i].OCRIndex=='X'){
            line[i].correlation=0;
        }
        if(line[i].OCRIndex=='W'&&line[i].name=="འ")line[i].OCRIndex='A';
        //else{
        //   line[i].correlation=line[i].correlationNew;
        //}
        //cout<<"i="<<i<<"letter->correlationNew="<<line[i].correlationNew<<endl;
    }
    
    
    int size=(int)line.size();
    
    
    //letterArea(line[54],letterAImg);
    //((GImageEditor*)inputData.imageEditor)->WriteImageData(letterAImg,"/_Image2OCR/_1Draw32.jpg",0); exit(0);
    
    //drawGrapeLine(line);exit(0);
    
    //    for(int i=0;i<size;i++){ //print=1;
    
    //        OCRMatch *letter=&line[i];
    //        if(!letter->correlation)continue;
    //if(letter->name!="རྕ")continue;
    //cout<<"letter.letter.size()="<<letter->letter.size()<<endl; exit(0);
    
    
    //((GImageEditor*)inputData.imageEditor)->WriteImageData(letterAImg,"/_Image2OCR/_1Draw32.jpg",0); exit(0);
    
    //        letterAImg->fillColumns32V(0, &line[i].s);  //стираем букву
    
    
    //    }
    
    
    for(int i=0;i<size;i++){
        
        OCRMatch *letter=&line[i];
        
        //cout<<i<<" "<<(char)letter->OCRIndex<<" "<<letter->correlation<<" "<<letter->name<<endl;
        
        if(!letter->correlation)continue;
        if(letter->OCRIndex=='V'||letter->OCRIndex=='W'||letter->OCRIndex=='R'||letter->OCRIndex=='X')continue; //пропускаем OpenType
        
        //проверяем, есть ли буквы более вероятные чем тестовая.
        //print=0; if(letter->name=="འི")print=1;   if(!print)continue;
        //print=0; if(i==207)print=1;   if(!print)continue;
        //cout<<"i="<<i<<" c="<<line[104].correlation<<" n="<<line[104].name<<endl;
        //cout<<" i1="<<line[128].letter[0].letterIndex<<" i2="<<line[128].letter[1].letterIndex<<endl;
        
        letterAImg->fillColumns32V(0, &line[i].s);  //стираем букву
        //проверяем, есть ли буквы более вероятные чем тестовая.
        //inputData.start=111;
        
        line[i].drawPict32(letterAImg,MATRIX_BORDER,ADD_MODE);
        
        //((GImageEditor*)inputData.imageEditor)->WriteImageData(letterAImg,"/_Image2OCR/_1Draw32.jpg",0); exit(0);
        
        //letterLineArea(line[i],lineImg32,letterAImg); //подсчитываем количество пикселов в букве; рисуем ее в letterAImg
        
        
        //сначала проверяем букву на соответствие графическому изображению на странице.
        //в пределах габарита буквы +-dY проверяем количество нераспознанных черных пикселов
        OCRBox s=line[i].s;
        s.y0=MATRIX_BORDER; s.y1=lineImg32->rows()-MATRIX_BORDER;
        //inputData.start=111;
        float pAreaPage=lineImg32->pixelCount(&s);
        
        line[i].pCount=lineImg32->img32UnionLine(letterAImg, &s);
        line[i].correlationNew=(pAreaPage+1)/(line[i].pCount+1);
        //количество нераспознанных пикселов (без нуля)
        DR(i<<" pAreaPage="<<pAreaPage<<" pCount="<<line[i].pCount<<" cN="<<line[i].correlationNew<<" n="<<line[i].name
           <<" x0="<<s.x0<<" x1="<<s.x1<<endl)
        
        
        if(letter->OCRIndex=='Z'){ dX_=10;}
        //int xLimit=letter->xCenter+dX;
        //int xLimit_=letter->xCenter-dX;
        int dir=1;
        //int flagReplace;
        int count=0;
        
        
        while(dir!=-1){
            //if(!letter->correlationNew)break;
            index=i+1;
            if(count==1){
                dir=-1;
                index=i-1;
            }
            if(dir>0) {DR(" test right"<<endl);} else {DR(" test left"<<endl)}
            
            while(1){
                if(index==-1||index==line.size())break;
                if(!line[index].correlation){ index+=dir; continue;}
                
                
                //проверяем есть ли пересечение букв.
                OCRBox s;
                intArea(&letter->s,&line[index].s,&s);
                
                if(s.area<letter->area/5&&s.area<line[index].area/5){
                    //DR("no intersection"<<endl)
                    index+=dir;
                    continue;
                }
                
                //строим изображение тестовой буквы
                letterBImg->fillColumns32V(0, &line[index].s);  //стираем букву
                letterLineArea(line[index],lineImg32,letterBImg); //подсчитываем количество пикселов в букве; рисуем ее в letterAImg
                //((GImageEditor*)inputData.imageEditor)->WriteImageData(letterBImg,"/_Image2OCR/_1Draw32.jpg",0); exit(0);
                //проверяем есть ли пересечение двух букв по отношению к фокальным линиям изображения
                int pArea=letterAImg->img32Union(letterBImg,&s);
                if(!pArea){ //(pArea<line[index].pCount/20&&pArea<line[i].pCount/20)
                    index+=dir;
                    continue;
                }
                float dC=(float)letter->correlation/line[index].correlation;
                float dP=((float)letter->pCount)/((float)line[index].pCount);
                float dPoint=letter->pCount-line[index].pCount;
                
                DR("//@@@*** Test_I letter A "<<letter->name<<" i="<<i<<" cI="<<letter->correlation<<" pCount="<<letter->pCount<<
                   " //  letter B "<<line[index].name<<" index="<<index
                   <<" cJ="<<line[index].correlation<<" pCount="<<line[index].pCount
                   <<"  //  dC="<<dC<<" dP="<<dP<<" dPoint/cN="<<dPoint/letter->pCount<<" pArea="<<pArea<<endl)
                
                if((dC>0.93&&dP>1.05)){  //неустойчивая проверка   dP>1.05  не менять
                    DR("remove J"<<endl);
                    line[index].correlation=0;
                    index+=dir;
                    continue;
                }
                if((dC>1&&dP>1)){  //неустойчивая проверка   dP>1.05  не менять
                    DR("remove J"<<endl);
                    line[index].correlation=0;
                    index+=dir;
                    continue;
                }
                if((dC>0.91&&dP>1.2)){
                    DR("remove J 1"<<endl);
                    line[index].correlation=0;
                    index+=dir;
                    continue;
                }
                if(dC<1.05&&dP<0.93){
                    DR("remove I _0"<<endl);
                    letter->correlation=0; dir=-1; break;
                }
                if(dC<0.95&&dP<1.05){
                    DR("remove I _1"<<endl);
                    letter->correlation=0; dir=-1; break;
                }
                if(dC<0.96&&dP<1){
                    DR("remove I _2"<<endl);
                    letter->correlation=0; dir=-1; break;
                }
                if(dC>0.97&&dP>0.98&&(line[index].name.find(xKey)!=-1&&letter->name.find(xKey)==-1)){
                    DR("remove J by X"<<endl);
                    line[index].correlation=0;
                    index+=dir;
                    continue;
                }
                if((letter->OCRIndex=='Z'||letter->OCRIndex=='N')&&(line[index].OCRIndex=='Z'||line[index].OCRIndex=='N')){
                    if(dC>1&&dP>0.95){
                        DR("remove J by Z"<<endl);
                        line[index].correlation=0;
                        index+=dir;
                        continue;
                    }else{
                        DR("remove I by Z"<<endl);
                        letter->correlation=0; dir=-1; break;
                    }
                }
                
                index+=dir;
            }
            count++;
        }
        //exit(0);
        //@@@@
        
        
    }
    
    /*
     DR(letter->name<<"@@@"<<i<<"@@@ "<<(char)letter->OCRIndex<<" xC="<<letter->xCenter<<" x0="<<letter->x0<<" x1="<<letter->x1<<" y0="<<letter->y0<<" y1="<<letter->y1<<" c="<<letter->correlation<<" dX="<<dX<<endl)
     
     while(dir!=-1){
     if(!letter->correlationNew)break;
     index=i+1;
     if(count==1){
     dir=-1;
     index=i-1;
     }
     if(dir>0) {DR(" test right"<<endl);} else {DR(" test left"<<endl)}
     
     while(1){
     if(index==-1||index==line.size())break;
     
     //if(mLetter->Character!=100){ dCMax=10;}else{dCMax=5;}
     OCRMatch *mLetter=&line[index];
     
     DR("@"<<mLetter->name<<" "<<(char)mLetter->OCRIndex<<" "<<index<<" xC="<<mLetter->xCenter<<" x0_="<<mLetter->x0<<" x1_="<<mLetter->x1<<" y0_="<<mLetter->y0<<" y1_="<<mLetter->y1<<" c="<<mLetter->correlation<<" cH="<<mLetter->Character<<endl)
     //if(index==1112){
     //    int a=1;
     //}
     
     
     if(mLetter->Character==100){
     if(mLetter->y0<letter->y0-dX*0.65&&
     abs(mLetter->xCenter-letter->xCenter)<dX_&&
     letter->correlation-mLetter->correlation<dCMax
     ){
     letter->correlationNew=0;  //учитываем верхние огласовки выше буквы
     DR("erase  by upper stack");
     break;
     
     }
     
     index+=dir;
     continue;
     
     } //для проверки используем OpenType
     
     //DR("i="<<index<<" mLetter->xCenter="<<mLetter->xCenter<<" xLimit_="<<xLimit_<<" xLimit="<<xLimit<<endl)
     if(mLetter->xCenter<xLimit_||mLetter->xCenter>xLimit)break;
     //DR(" mLetter->correlation="<<mLetter->correlation<<endl)
     if(!mLetter->correlation){index+=dir;continue;}
     if(mLetter->OCRIndex=='Z'&&mLetter->delimeter!="•"){index+=dir;continue;} //пропускаем знаки препинания
     DR(mLetter->name<<" "<<(char)mLetter->OCRIndex<<" "<<index<<" xC="<<mLetter->xCenter<<" x0_="<<mLetter->x0<<" x1_="<<mLetter->x1<<" y0_="<<mLetter->y0<<" y1_="<<mLetter->y1<<" c="<<mLetter->correlation<<" cH="<<mLetter->Character<<" letter->correlation="<<letter->correlation<<endl)
     flagReplace=0;
     int dC=letter->correlation-mLetter->correlation;
     
     if(mLetter->OCRIndex=='V'&&letter->OCRIndex!='Z'){
     if(letter->name.find(xKey)!=-1){
     if(abs(mLetter->xCenter-letter->xCenter)<dX*0.65
     &&letter->name.find(mLetter->name)==-1){
     if(mLetter->y0<letter->y0+dX_&&mLetter->y1>letter->y0-dX&&mLetter->correlation>85){
     flagReplace=1; //учитываем верхние огласовки выше буквы
     }
     }
     }else{
     if(mLetter->xCenter>letter->x0&&mLetter->xCenter<letter->x1){
     if(mLetter->y0<letter->y0-dX_
     &&mLetter->y1>letter->y0-dX
     &&dC<dCMax){
     flagReplace=1; //учитываем верхние огласовки выше буквы
     }
     if(mLetter->name=="ཾ"){
     if(mLetter->correlation>90&&letter->name.find("ཾ")==-1){
     flagReplace=1; //учитываем верхние огласовки выше буквы
     }
     }
     }
     }
     if(dC<dCMax&&letter->name.find("ཾ")!=-1){
     if(abs(mLetter->xCenter-letter->xCenter)<letter->letterW/2){
     if(mLetter->y0>letter->y0-dX_&&mLetter->y0<letter->y0+dX_&&letter->name.find(mLetter->name)==-1){
     flagReplace=1; //учитываем верхние огласовки совместно с дополнительными огласовками
     }
     }
     }
     
     }
     
     if((mLetter->OCRIndex=='W'||mLetter->OCRIndex=='R')&&letter->OCRIndex!='Z'){ //@@@
     if(mLetter->xCenter>letter->x0&&mLetter->xCenter<letter->x1){
     if(mLetter->y1>letter->y1+dX/4&&
     mLetter->y0<letter->y1+dX&&
     dC<dCMax&&
     letter->name.find(mLetter->name)==-1){
     flagReplace=2; //учитываем нижние огласовки ниже буквы //учитываем нижние приписные ниже буквы
     }
     }
     }
     //cout<<" dC="<<dC<<" dCMax="<<dCMax<<endl;
     if((mLetter->OCRIndex=='W'||mLetter->OCRIndex=='R')&&mLetter->Character!=100&&letter->OCRIndex!='Z'){
     //cout<<" dX="<<dX<<" dX1="<<abs(mLetter->xCenter-letter->xCenter)<<" dC="<<dC<<endl;
     if(mLetter->xCenter>letter->x0&&mLetter->xCenter<letter->x1){
     if(mLetter->y0>letter->y0&&
     mLetter->y1<letter->y1+dX&&
     dC<dCMax&&
     letter->name.find(mLetter->name)==-1){
     if(mLetter->name!="ྲ"){
     if(mLetter->name!="འ"){
     if(mLetter->name=="ུ"&&
     (letter->name.find("ི")!=-1||letter->name.find("ོ")!=-1||letter->name.find("ེ")!=-1)){
     }else{
     flagReplace=5; //учитываем нижние огласовки и приписные внутри буквы
     }
     }else if(letter->name.find("ལ")==-1){
     flagReplace=5; //учитываем нижние огласовки и приписные внутри буквы
     }
     if(mLetter->name=="ྭ"&&letter->name.find("ཕ")!=-1){
     if(letter->name.find("ྱ")==-1){
     flagReplace=0;
     }else{
     if(mLetter->y1>letter->y1)flagReplace=4;
     }
     }
     if(mLetter->name=="ུ"&&letter->name.find("ཨ")!=-1){
     flagReplace=0;
     }
     }else{
     if(letter->name.find("ུ")!=-1&&mLetter->y1>letter->y1-mLetter->letterW*2){
     if(letter->name.find("ཟ")!=-1){}else{
     flagReplace=5; //учитываем нижние огласовки и приписные внутри буквы
     }
     }else{
     if(lastOf(letter->name)=="ར"){
     flagReplace=0;
     }else{
     if(mLetter->y0>letter->y1-25){
     flagReplace=5; //учитываем нижние огласовки и приписные внутри буквы
     }
     }
     }
     }
     
     
     }
     if(mLetter->OCRIndex=='W'&&mLetter->y0<letter->y0&&mLetter->y0>letter->y0-dX&&dC<dCMax){
     flagReplace=5; //учитываем нижние огласовки выше буквы
     }
     
     }
     }
     if(mLetter->OCRIndex=='X'&&abs(mLetter->xCenter-letter->xCenter)<10&&dC<dCMax/2&&
     letter->name.find(mLetter->name)==-1&&
     (letter->name.find("ཇ")!=-1||letter->name.find("ཅ")!=-1||letter->name.find("ཆ")!=-1)
     &&letter->name.find("ལཇ")==-1&&letter->name.find("ལཅ")==-1){
     flagReplace=5;
     }
     
     if(mLetter->OCRIndex!='V'&&mLetter->OCRIndex!='R'&&mLetter->OCRIndex!='W'&&mLetter->OCRIndex!='X'){
     if(letter->OCRIndex!='Z'){
     if(abs(mLetter->xCenter-letter->xCenter)<letter->letterW/2){
     if(mLetter->Character!=100){
     if(mLetter->y0<letter->y0-10&&dC<dCMax/2){
     if(mLetter->name=="ཟ"&&letter->name.find("ར")!=-1){
     index+=dir; continue;
     }else{
     flagReplace=3;                        //учитываем коренные буквы выше буквы
     }
     }
     if(hasTail(line[index])){
     if(mLetter->y1>letter->y1+mLetter->letterH*0.7&&dC<dCMax){
     flagReplace=4;                        //учитываем коренные буквы ниже буквы
     }
     //if(letter->name.find("ང")!=-1&&mLetter->name=="ད"&&mLetter->y0>letter->y0+dX&&dC<2){
     //    flagReplace=4;                        //учитываем коренные буквы ниже буквы
     //}
     }else{
     if(mLetter->y1>letter->y1+dX/2&&dC<3){   //dX_!
     if(mLetter->name=="བ"){
     if(letter->name.find("ཁ")==-1&&letter->name.find("ག")==-1&&letter->name.find("ཤྲ")==-1
     &&mLetter->y1>letter->y1+dX)flagReplace=4;
     }else{
     flagReplace=4;                        //учитываем коренные буквы ниже буквы
     }
     }
     if(mLetter->name=="ར"&&letter->name.find("ར")==-1&&mLetter->y0<y1Base&&dC<2){
     if(mLetter->yCenter>letter->y0&&
     mLetter->yCenter<letter->y1&&
     letter->name.find("ཇ")==-1&&
     letter->name.find("ཟ")==-1){
     flagReplace=5;                        //учитываем букву Ра внутри буквы
     }
     }
     }
     }else{
     if(mLetter->y0<letter->y0-12&&dC<dCMax){
     flagReplace=3;                        //учитываем коренные буквы выше буквы
     }
     if(mLetter->y1>letter->y1+12&&dC<dCMax/2){
     flagReplace=4;                        //учитываем коренные буквы ниже буквы
     }
     }
     }
     }else{
     if((mLetter->x0<letter->xCenter&&mLetter->x1>letter->xCenter)||
     (mLetter->x1>letter->xCenter&&mLetter->x0<letter->xCenter)){
     if(mLetter->Character!=100&&dC<0){
     flagReplace=4;
     DR("remove by Z letter"<<endl)
     letter->correlationNew=0;
     }
     }
     }
     
     }
     if(flagReplace){
     if(print){
     DR("flagReplace="<<flagReplace<<endl)
     if(flagReplace==1)DR("remove letter by vowel  ")
     if(flagReplace==2)DR("remove letter by joined  ")
     if(flagReplace==3)DR("remove letter up  ")
     if(flagReplace==4)DR("remove letter down  ")
     if(flagReplace==5)DR("remove inside join  ")
     DR("c="<<letter->correlation<<"   ")
     }
     
     DR(letter->name<<">>"<<mLetter->name<<"_____@ x0="<<letter->x0<<" x1="<<letter->x1<<" y0="<<letter->y0<<" y1="<<letter->y1<<endl)
     if(mLetter->Character!=100){
     if(flagReplace==2){//&&letter->name.find(mLetter->name)==-1
     letter->correlationNew=0;
     }
     if(flagReplace==4){
     if(letter->name.find(mLetter->name)==-1)letter->correlationNew=0;
     }
     if(flagReplace==1||flagReplace==3)letter->correlationNew=0;
     
     if(flagReplace==5){
     if(letter->name.find("ཅ")!=-1&&mLetter->name=="ུ"){
     if(mLetter->y0>letter->y1-10){
     letter->correlationNew=0; //учитываем нижние огласовки ниже буквы
     }
     }else{
     letter->correlationNew=0;
     }
     }
     
     
     }else{
     if((flagReplace==2||flagReplace==4)&&mLetter->name.find("ྭ")==-1){
     if(flagReplace==2)letter->correlationNew-=2;
     if(flagReplace==4){
     if(mLetter->name.find("ུ")!=-1){letter->correlationNew-=(float)0.1;} else{letter->correlationNew-=1;}
     }
     }
     if(flagReplace==1)letter->correlationNew-=(float)0.1;
     if((flagReplace==3||flagReplace==1)&&mLetter->name.find("ེ")!=-1){
     letter->correlationNew-=(float)0.1;
     }else{
     if(flagReplace==3||flagReplace==1)letter->correlationNew-=(float)0.3;
     }
     }
     DR(" new c="<<letter->correlationNew<<endl)
     if(!letter->correlationNew)break;
     }
     
     index+=dir;
     }
     
     count++;
     }
     }
     
     //стираем огласовки и приписные буквы
     for(int i=0;i<line.size();i++){
     if(line[i].OCRIndex=='V'||line[i].OCRIndex=='W'||line[i].OCRIndex=='R'||line[i].OCRIndex=='X'){
     line[i].correlation=0;
     }else{
     line[i].correlation=line[i].correlationNew;
     }
     //cout<<"i="<<i<<"letter->correlationNew="<<line[i].correlationNew<<endl;
     }
     */
    
}