#include "GBitsetOCR.h"

void GBitsetOCR::setOCRRecordCorrelation(){  //SET CORRELATION FOR TWO RECORDS IN BASE

//short correlationByCassidy=0, correlationByCassidy1=0, correlationByLimit=0, correlationByStructure=0, correlationByOCRZone=0, correlationByHollogram=0, i;
//float k1,k2,k3;
//short print=0; ////@ //temporary print command

//cout <<" l "<<letterModelBase[record].name;

//@DC("glyph->letterIndex="<<glyph.letterIndex<<END);


	//correlationByHollogram=setHollogramCorrelation();

	            //contourTestBase[currentRecord_].correlationMethod=6;//}   ///////OCR FLAG SET 	
//@DC(" correlationByHollogram="<<correlationByHollogram<<END);

/*
	
 /////EIGTH STEP we test much in somу zone in contour				
				//if(correlationByHollogram>=50){  
				//	 correlationByOCRZone=[self setOCRZoneCorrelation
				//						:letterModelBase
				//						:record
				//						:correlationByHollogram];
				//contourTestBase[currentRecord_].correlationMethod=7;}
				////@cout <<" correlationByOCRZone="<<correlationByOCRZone;
												   				
			if(correlationByHollogram>maxCorrelation){ 
			maxCorrelationRecord=record; maxCorrelation=correlationByHollogram;
				if(maxCorrelation>contourTestBase[currentRecord_].correlation){
					for(i=0;i<20;i++)contourTestBase[currentRecord_].name[i]=letterModelBase[record].name[i];
					contourTestBase[currentRecord_].correlation=maxCorrelation; //test letter now has max correlation value with letters in OCR base
					contourTestBase[currentRecord_].match1=letterModelBase[record].letterIndex;
					contourTestBase[currentRecord_].OCRStatus=letterModelBase[record].OCRStatus;
					contourTestBase[currentRecord_].contour=3; //cout<<"/////////////////////////contourTestBase["<<currentRecord_<<"].contour="<<3<<endl;
				}
			                     
						//contourTestBase[currentRecord_].correlationByLimit=correlationByLimit;	
				                //contourTestBase[currentRecord_].correlationByStructure=correlationByStructure;
					        //contourTestBase[currentRecord_].correlationByCassidy=correlationByCassidy;
						//contourTestBase[currentRecord_].correlationByCassidy1=correlationByCassidy1;
						//contourTestBase[currentRecord_].correlationByOCRZone=correlationByOCRZone;
						//contourTestBase[currentRecord_].correlationByHollogram=correlationByHollogram;
										
                       //@cout<<"record="<<record<<"currentRecord_="<<currentRecord_<<"letter="<<letterModelBase[maxCorrelationRecord].letterIndex<<" maxCorrelation="<<maxCorrelation<<endl;
			}
			
			//@cout<<"// "<<letterModelBase[record].letterIndex<<" maxCorrelation="<<maxCorrelation
			<<"contourTestBase["<<currentRecord_<<"].correlation"<<contourTestBase[currentRecord_].correlation<<endl;		
		
				}//if(k3<2&&k3>0.5)  vectorCount
				}//if(k3>0.7){ //letter proportion1
				}//if(k3>0.7){//letter proportion2
				//}//end if(contourTestBase[record].angLength
				
                        //contourTestBase[currentRecord_].OCRTableRecord1=maxCorrelationRecord;
*/
 }/////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
