
#if FOO
#if BAR
#include <foo>
#endif
#endif

#define A \
int aaaa; \
int b; \
int dddddddddd;

for(int tt=0;
    
    tt<100;tt++)   {
  if(sz==1){1;}else        {sz=sz/3;}
  (int)sz++;}

            if(sz>100) return 0;
if(sz>100) {return 0;}

int tt=1; float dd=3;

//;
tt=1;dd=3;tt=1;dd=3;tt=1;dd=3;tt=1;dd=3;tt=1;dd=3;
tt=1;dd=3;tt=1;dd=3;tt=1;dd=3;tt=1;dd=3;tt=1;dd=3;
tt=1;dd=3;tt=1;dd=3;tt=1;dd=3;tt=1;dd=3;tt=1;dd=3;
//_



char *p; ///char p
char     *dd;  //char dd
int aaaa=12;
int b=23;
int ccc=23;

true:
switch (a) {
  case 1: x = 1; break;
  case 2: return;
}                             
    
            vector <   int>ad;
ad  [    32]+=21/6;

cout<<endl<<"1_______________________________________________________________________________________"<<endl;
cout<<endl<<"2___________________________________________________________________"<<endl;

memcpy(
       p,
       drfhdrjhedtyjtryjrtyjrtyjrtyjrtyjrtyjrtyjd,
       100);

t f( Deleted & ) & = delete;

bool value = aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa +aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ==
aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
&&   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa >
ccccccccccccccccccccccccccccccccccccccccc;

/** @brief Returns main string in HTML    format as result of grammar correction by dictionary base */
void grammarCorrector(vector<stringOCR>   &strArray,
                      vector<     stringOCR>     &correctionWordArray,string &mainString,
                                    string &xmlString);

//adrgsdfgbsdbg



