
#ifdef HAVE_CONFIG_H
# include "config.h"
#endif
#if NEED_GNUG_PRAGMAS
# pragma implementation
#endif

#include <iostream>
using namespace std;

#include "GBitsetOCR.h"
#include <string.h>
#include <time.h>
#include <math.h>



namespace ocr {

}
using namespace ocr;



